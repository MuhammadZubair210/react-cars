import React from 'react';
import TextField from 'material-ui/TextField';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider'
import './Login.css'

const TextFieldExampleSimple = () => (
    <MuiThemeProvider>
        <div className="border">
            <TextField
                hintText="Hint Text"
                floatingLabelText="Fixed Floating Label Text"
                floatingLabelFixed={true}
            />
        </div><br />
         <div className="border"> 
              <TextField
                hintText="Hint Text"
                floatingLabelText="Fixed Floating Label Text"
                floatingLabelFixed={true} 
            />
        </div>
        <br />
        <div className="border">
            <TextField
                hintText="Hint Text"
                floatingLabelText="Fixed Floating Label Text"
                 floatingLabelFixed={true} 
            />
        </div>
        <br />
        <div className="border">
            <TextField
                hintText="Hint Text"
                floatingLabelText="Fixed Floating Label Text"
                floatingLabelFixed={true}
            />
        </div>
        <br />
    </MuiThemeProvider>
);

export default TextFieldExampleSimple;